<?php


?>


  
  
<img alt="TESTING" src="/code/barcode.php?codetype=Code39&size=40&text=TESTING&print=true" />
  
  